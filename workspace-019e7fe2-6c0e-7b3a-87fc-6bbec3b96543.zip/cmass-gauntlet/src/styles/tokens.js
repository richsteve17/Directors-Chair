// Shared design tokens (Fix #13 — stop repeating inline magic values).
// Contrast note (Fix #10): STEEL was #7d8a96 on near-black, which fails WCAG AA
// for small text. STEEL_DIM keeps the muted look for large/non-essential text;
// STEEL is lightened for small body/labels; minimum body sizes bumped up.

export const ACCENT = "#d9783b";        // slightly brighter than the old #c9682f for AA on dark
export const ACCENT_SOFT = "#f0d9c4";
export const STEEL = "#9aa7b3";          // lightened for readable small text
export const STEEL_DIM = "#7d8a96";      // original tone, for large/decorative only
export const BG = "#0a0c0e";
export const PANEL = "#15181c";
export const PANEL_2 = "#1a1e22";
export const BORDER = "#2c333a";
export const TEXT = "#ece7df";
export const TEXT_SOFT = "#cfcabf";

export const SANS = "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
export const SERIF = "Georgia, 'Times New Roman', serif";

export const STORE_KEY = "cmass_gauntlet_state_v2";

export const wrapStyle = { minHeight: "100vh", background: BG, color: TEXT, fontFamily: SERIF };
export const innerStyle = { maxWidth: 640, margin: "0 auto", padding: "22px 16px 96px" };

export const btnPrimary = {
  background: ACCENT,
  color: "#1a0f07",
  border: "none",
  borderRadius: 8,
  padding: "13px",
  fontSize: 15,
  fontWeight: 800,
  fontFamily: SANS,
  cursor: "pointer",
};

export const btnGhost = {
  background: "transparent",
  color: ACCENT,
  border: `1px solid ${ACCENT}`,
  borderRadius: 8,
  padding: "13px",
  fontSize: 15,
  fontWeight: 700,
  fontFamily: SANS,
  cursor: "pointer",
};
